package com.第六题;

public class Student {
    private Integer xuehao;
    private String name;
    private String sex;
    private Integer age;
    public static String nianji="17级";

    public Student(Integer xuehao, String name, String sex) {
        this.xuehao = xuehao;
        this.name = name;
        this.sex = sex;
    }

    public Student(Integer xuehao, String name, String sex, Integer age) {
        this.xuehao = xuehao;
        this.name = name;
        this.sex = sex;
        this.age = age;
    }

    public Integer getXuehao() {
        return xuehao;
    }

    public void setXuehao(Integer xuehao) {
        this.xuehao = xuehao;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public static String getNianji() {
        return nianji;
    }

    public static void setNianji(String nianji) {
        Student.nianji = nianji;
    }
    public static void display(){
        System.out.println(nianji);
    }
    public void show(){
        System.out.println(this.getXuehao()+this.getName());
    }

}
