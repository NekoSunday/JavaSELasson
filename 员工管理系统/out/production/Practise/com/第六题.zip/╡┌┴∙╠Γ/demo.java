package com.第六题;

public class demo {
    public static void main(String[] args) {
        Student student1= new Student(17,"张三","男");
        Student student2= new Student(18,"李四","男",18);
        student1.show();
        student2.show();
    }
}
