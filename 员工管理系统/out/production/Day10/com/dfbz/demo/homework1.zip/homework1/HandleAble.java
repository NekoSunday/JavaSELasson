package com.dfbz.demo.homework1;

public interface HandleAble {
    String HandleString(String num);
}
