package com.dfbz.demo.homework1;

public class Test {
    public static void main(String[] args) {
        String num="23.23456789";
        HandleAble handleAble=(String)->{
                String num1=num.substring(0,num.indexOf("."));
                return num1;
        };
        String string = handleAble.HandleString(num);
        System.out.println("源数字为："+num);
        System.out.println("取整数后："+string);
        String num2=num.substring(0,7);
        if(num.charAt(7)>5){
            double num3=Double.valueOf(num2)+0.0001;
            System.out.println("保留四位数后："+num3);
        }

    }
}
