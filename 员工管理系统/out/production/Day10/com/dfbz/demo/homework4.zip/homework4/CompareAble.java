package com.dfbz.demo.homework4;

public interface CompareAble {
    public default void compare(){
        System.out.println("挑选大的苹果:");
    }
}
