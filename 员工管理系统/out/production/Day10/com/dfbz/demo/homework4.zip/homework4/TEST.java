package com.dfbz.demo.homework4;

public class TEST {
    public static void main(String[] args) {
        Worker worker=new Worker();
        Apple apple1=new Apple(5,"青色");
        Apple apple2=new Apple(3,"红色");
        Compare compare=new Compare();
        compare.compare();
        worker.chooseApple(compare,apple1,apple2);


    }
}
