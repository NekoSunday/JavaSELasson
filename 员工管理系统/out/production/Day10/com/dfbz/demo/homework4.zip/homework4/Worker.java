package com.dfbz.demo.homework4;

public class Worker extends Apple{
    public void chooseApple(CompareAble compareAble,Apple a1,Apple a2){
        if(a1.getSize()>a2.getSize()){
            System.out.println((double)a1.getSize()+"------"+a1.getColor());
        }else {
            System.out.println((double)a2.getSize()+"------"+a2.getColor());
        }
        if(a2.getColor()=="红色"||a1.getColor()=="红色"){
            System.out.println("挑"+a2.getColor()+"的：");
            System.out.println((double)(a2.getSize())+"---"+a2.getColor());
        }else {
            System.out.println("挑"+a1.getColor()+"的：");
            System.out.println((double)(a1.getSize())+"---"+a1.getColor());
        }

    }
}
