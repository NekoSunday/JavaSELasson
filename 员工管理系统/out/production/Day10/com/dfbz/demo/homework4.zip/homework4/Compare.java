package com.dfbz.demo.homework4;

public class Compare implements CompareAble {
}
